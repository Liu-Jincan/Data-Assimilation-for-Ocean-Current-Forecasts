
clear all;
clc

bg=load('bg_data_2.txt');
assiresult=load('assiresult.grbtxt');

plot(bg,assiresult,'k.')


