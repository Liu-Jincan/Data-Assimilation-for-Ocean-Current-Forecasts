Freerun output saves here for computing the background matrix (i.e. B and A matrices).
