background file will be copied here by the data assimilation code
